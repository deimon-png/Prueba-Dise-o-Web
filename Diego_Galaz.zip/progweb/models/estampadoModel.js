const fs = require('fs');
const path = require('path');

const rutaArchivo = path.join(__dirname, '..', 'data', 'estampados.json');

function obtenerTodos() {
    if (!fs.existsSync(rutaArchivo)) return [];
    const contenido = fs.readFileSync(rutaArchivo, 'utf-8');
    if (contenido.trim() === '') return [];
    return JSON.parse(contenido);
}

function guardarEstampados(estampados) {
    fs.writeFileSync(rutaArchivo, JSON.stringify(estampados, null, 4));
}

function importarEstampados(nuevos) {
    const existentes = obtenerTodos();
    let importados = 0;
    let actualizados = 0;

    for (const estampado of nuevos) {
        const indice = existentes.findIndex(e => e.nombre === estampado.nombre);
        if (indice === -1) {
            existentes.push(estampado);
            importados++;
        } else {
            existentes[indice] = estampado;
            actualizados++;
        }
    }

    guardarEstampados(existentes);
    return { importados, actualizados };
}

function reportePorCategoria() {
    const estampados = obtenerTodos();
    const reporte = {};

    for (const e of estampados) {
        const cat = e.categoria || 'Sin categoría';
        if (!reporte[cat]) {
            reporte[cat] = { categoria: cat, total_productos: 0, precio_min: Infinity, precio_max: -Infinity, suma: 0 };
        }
        reporte[cat].total_productos++;
        reporte[cat].suma += e.precio;
        if (e.precio < reporte[cat].precio_min) reporte[cat].precio_min = e.precio;
        if (e.precio > reporte[cat].precio_max) reporte[cat].precio_max = e.precio;
    }

    return Object.values(reporte).map(r => ({
        categoria: r.categoria,
        total_productos: r.total_productos,
        precio_min: r.precio_min,
        precio_max: r.precio_max,
        precio_promedio: Math.round(r.suma / r.total_productos)
    }));
}

module.exports = { obtenerTodos, importarEstampados, reportePorCategoria };
